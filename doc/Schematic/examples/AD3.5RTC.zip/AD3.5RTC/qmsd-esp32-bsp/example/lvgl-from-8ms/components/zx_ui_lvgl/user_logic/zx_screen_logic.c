#include "zx_screen_logic.h"

void zx_screen_logic_install() {
    screen_main_logic_install();
}