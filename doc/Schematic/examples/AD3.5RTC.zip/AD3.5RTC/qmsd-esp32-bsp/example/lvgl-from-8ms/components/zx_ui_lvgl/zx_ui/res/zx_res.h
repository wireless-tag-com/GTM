#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "font/zx_fonts.h"
#include "image/zx_images.h"

#ifdef __cplusplus
}
#endif