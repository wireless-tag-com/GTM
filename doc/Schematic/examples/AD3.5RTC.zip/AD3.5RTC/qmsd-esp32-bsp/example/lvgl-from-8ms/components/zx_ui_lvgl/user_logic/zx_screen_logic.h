#pragma once

#include "zx_ui_entry.h"

void screen_main_logic_install();

void zx_screen_logic_install();