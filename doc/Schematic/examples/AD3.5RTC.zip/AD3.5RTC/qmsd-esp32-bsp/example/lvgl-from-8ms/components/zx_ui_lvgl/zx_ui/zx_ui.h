#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"
#include "components/driver_base/zx_ui_base_driver.h"
#include "res/zx_res.h"

#ifdef __cplusplus
}
#endif
