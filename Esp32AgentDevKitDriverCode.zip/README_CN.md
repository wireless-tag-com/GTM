屏幕驱动基于`QMSD-ESP32-BSP`,如果您是第一次接触`QMSD-ESP32-BSP`,可移步`QMSD-ESP32-BSP`<https://github.com/smartpanle/QMSD-ESP32-BSP>

# 使用说明

## 测试使用环境如下

- **IDF 版本** 5.3 ([Link to IDF v5.3.2](https://github.com/espressif/esp-idf/tree/v5.3.2))
- **ADF 版本** ([Link to ESP-ADF](https://github.com/espressif/esp-adf))

# IDF环境

此处不做介绍，详情参考esp-idf中的`README.md`文件.

## ADF环境

1. 下载ESP-ADF到本地
2. 在`esp-adf/idf_patches`目录下有对应esp-idf版本的补丁,按照该目录下的`README.md`文件打上对应的补丁.
3. 添加`ADF_PATH`环境变量
    - **方法一**：按照esp-adf中的`README.md`文件进行添加
    - **方法二**：修改CMakeLists.txt文件中的"./esp-adf"路径

    ```cmake
    if(NOT DEFINED ENV{ADF_PATH})
        set(ENV{ADF_PATH} "./esp-adf")
    endif()
    ```

## esp-idf问题

如果提示`lcd_periph_signals`报错,修改`QMSD-ESP32-BSP/components/qmsd_screen/rgb_panel/qmsd_lcd_panel_rgb.c`路径下的文件,更改判断esp-idf版本

```c
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 2)
#define lcd_periph_signals lcd_periph_rgb_signals
#endif
```

## 说明

- `esp_peripherals`来源于`esp-adf/components/esp_peripherals`主要修改`esp_peripherals/driver/i2c_bus`下的`i2c_bus.c`和`i2c_bus.h`文件，适配屏幕使用的i2c库
- `board_to_adf`此处初始化驱动`ES7210`和`ES8311`,如果对此有疑问请移步`ESP-ADF`
- `QM-Y1091-4832`为屏幕驱动配置部分
